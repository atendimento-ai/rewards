import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
  const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

  // Auto-detect swapped env vars
  let biatrixApiUrl = Deno.env.get("BIATRIX_API_URL") ?? "";
  let biatrixApiKey = Deno.env.get("BIATRIX_API_KEY") ?? "";
  if (biatrixApiUrl.startsWith("bx_") && biatrixApiKey.startsWith("http")) {
    const tmp = biatrixApiUrl;
    biatrixApiUrl = biatrixApiKey;
    biatrixApiKey = tmp;
  }

  let syncLogId: string | null = null;
  const adminClient = createClient(supabaseUrl, serviceRoleKey);

  try {
    // 1. Authenticate caller
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const anonClient = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } },
    });

    const token = authHeader.replace("Bearer ", "");
    const { data: claims, error: claimsError } = await anonClient.auth.getClaims(token);
    if (claimsError || !claims?.claims) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const userId = claims.claims.sub;
    const { data: callerProfile } = await anonClient
      .from("profiles")
      .select("id, role, company_id")
      .eq("auth_user_id", userId)
      .single();

    if (callerProfile?.role !== "admin") {
      return new Response(JSON.stringify({ error: "Forbidden: admin only" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // 2. Get company and biatrix_company_id
    const { company_id: bodyCompanyId } = await req.json();
    const companyId = bodyCompanyId || callerProfile.company_id;

    const { data: company } = await adminClient
      .from("companies")
      .select("id, biatrix_company_id, name")
      .eq("id", companyId)
      .single();

    if (!company?.biatrix_company_id) {
      return new Response(
        JSON.stringify({ error: "Company not linked to Biatrix. Set biatrix_company_id first." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // 3. Log sync start
    const { data: syncLog } = await adminClient
      .from("biatrix_sync_logs")
      .insert({ company_id: companyId, sync_type: "full", status: "started" })
      .select("id")
      .single();

    syncLogId = syncLog?.id ?? null;

    // 4. Call Biatrix org-chart-export
    if (!biatrixApiUrl || !biatrixApiKey) {
      throw new Error("BIATRIX_API_URL and BIATRIX_API_KEY must be configured.");
    }

    const biatrixRes = await fetch(`${biatrixApiUrl}/functions/v1/org-chart-export`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${biatrixApiKey}`,
      },
      body: JSON.stringify({ company_id: company.biatrix_company_id }),
    });

    if (!biatrixRes.ok) {
      const errText = await biatrixRes.text();
      throw new Error(`Biatrix API error (${biatrixRes.status}): ${errText}`);
    }

    const biatrixData = await biatrixRes.json();
    if (!biatrixData.success || !biatrixData.data) {
      throw new Error(biatrixData.error || "Biatrix returned unsuccessful response");
    }

    const { sectors = [], collaborators = [] } = biatrixData.data;
    let recordsSynced = 0;

    // 5. Sync sectors — first pass: upsert without parent_id
    for (const sector of sectors) {
      await adminClient
        .from("sectors")
        .upsert(
          {
            company_id: companyId,
            biatrix_id: sector.id,
            name: sector.name,
            description: sector.description || null,
            level: sector.level ?? 0,
            hierarchy_order: sector.hierarchy_order ?? 0,
            is_advisory: sector.is_advisory ?? false,
            synced_at: new Date().toISOString(),
          },
          { onConflict: "company_id,biatrix_id" }
        );
      recordsSynced++;
    }

    // Second pass: update parent_id
    for (const sector of sectors) {
      if (sector.parent_id) {
        const { data: parentRow } = await adminClient
          .from("sectors")
          .select("id")
          .eq("company_id", companyId)
          .eq("biatrix_id", sector.parent_id)
          .single();

        if (parentRow) {
          await adminClient
            .from("sectors")
            .update({ parent_id: parentRow.id })
            .eq("company_id", companyId)
            .eq("biatrix_id", sector.id);
        }
      }
    }

    // 6. Sync collaborators
    const syncedBiatrixIds: string[] = [];

    for (const collab of collaborators) {
      syncedBiatrixIds.push(collab.id);

      // Try to find existing profile by biatrix_collaborator_id
      let { data: existingProfile } = await adminClient
        .from("profiles")
        .select("id, auth_user_id")
        .eq("company_id", companyId)
        .eq("biatrix_collaborator_id", collab.id)
        .maybeSingle();

      // Fall back to email match
      if (!existingProfile && collab.email) {
        const { data: emailMatch } = await adminClient
          .from("profiles")
          .select("id, auth_user_id")
          .eq("company_id", companyId)
          .eq("email", collab.email)
          .maybeSingle();
        existingProfile = emailMatch;
      }

      if (existingProfile) {
        // Update existing profile
        await adminClient
          .from("profiles")
          .update({
            name: collab.full_name || collab.name,
            biatrix_collaborator_id: collab.id,
            is_active: collab.status === "active",
          })
          .eq("id", existingProfile.id);
        recordsSynced++;
      } else if (collab.status === "active" && collab.email) {
        // Create new user — trigger creates profile
        const { data: newUser, error: createErr } = await adminClient.auth.admin.createUser({
          email: collab.email,
          password: crypto.randomUUID(),
          email_confirm: true,
          user_metadata: {
            name: collab.full_name || collab.name,
            role: "collaborator",
          },
        });

        if (!createErr && newUser?.user) {
          // Update the auto-created profile with biatrix_collaborator_id
          await adminClient
            .from("profiles")
            .update({ biatrix_collaborator_id: collab.id })
            .eq("auth_user_id", newUser.user.id);
          recordsSynced++;
        }
      }
    }

    // 7. Deactivate stale profiles
    if (syncedBiatrixIds.length > 0) {
      const { data: allLinked } = await adminClient
        .from("profiles")
        .select("id, biatrix_collaborator_id")
        .eq("company_id", companyId)
        .not("biatrix_collaborator_id", "is", null);

      if (allLinked) {
        const stale = allLinked.filter(
          (p) => !syncedBiatrixIds.includes(p.biatrix_collaborator_id!)
        );
        for (const s of stale) {
          await adminClient.from("profiles").update({ is_active: false }).eq("id", s.id);
        }
      }
    }

    // 8. Update company name if provided
    if (biatrixData.data.company_name) {
      await adminClient
        .from("companies")
        .update({ name: biatrixData.data.company_name })
        .eq("id", companyId);
    }

    // 9. Update sync log — success
    if (syncLogId) {
      await adminClient
        .from("biatrix_sync_logs")
        .update({
          status: "completed",
          records_synced: recordsSynced,
          completed_at: new Date().toISOString(),
        })
        .eq("id", syncLogId);
    }

    return new Response(
      JSON.stringify({ success: true, records_synced: recordsSynced }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err: any) {
    // Update sync log — failure
    if (syncLogId) {
      await adminClient
        .from("biatrix_sync_logs")
        .update({
          status: "failed",
          error_message: err?.message || "Unknown error",
          completed_at: new Date().toISOString(),
        })
        .eq("id", syncLogId);
    }

    return new Response(
      JSON.stringify({ error: err?.message || "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
