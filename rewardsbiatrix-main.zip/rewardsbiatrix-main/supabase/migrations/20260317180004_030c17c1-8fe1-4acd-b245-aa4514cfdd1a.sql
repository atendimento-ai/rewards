
-- Function 1: get_points_balance
CREATE OR REPLACE FUNCTION public.get_points_balance(p_profile_id UUID)
RETURNS INTEGER
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT COALESCE(
    SUM(
      CASE
        WHEN transaction_type IN ('earned', 'adjustment') THEN points
        WHEN transaction_type IN ('redeemed', 'expired') THEN -points
        ELSE 0
      END
    ),
    0
  )::INTEGER
  FROM public.reward_points
  WHERE profile_id = p_profile_id;
$$;

-- Function 2: redeem_prize
CREATE OR REPLACE FUNCTION public.redeem_prize(
  p_profile_id UUID,
  p_prize_id UUID,
  p_company_id UUID,
  p_idempotency_key UUID
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_prize RECORD;
  v_balance INTEGER;
  v_existing_id UUID;
  v_redemption_id UUID;
BEGIN
  -- 1. Lock the prize row
  SELECT * INTO v_prize
  FROM public.reward_prizes
  WHERE id = p_prize_id
  FOR UPDATE;

  -- 2. Validate prize
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Prize not found';
  END IF;
  IF NOT v_prize.is_active THEN
    RAISE EXCEPTION 'Prize is not active';
  END IF;
  IF v_prize.expiration_date IS NOT NULL AND v_prize.expiration_date < CURRENT_DATE THEN
    RAISE EXCEPTION 'Prize has expired';
  END IF;
  IF v_prize.quantity_available <= 0 THEN
    RAISE EXCEPTION 'Prize out of stock';
  END IF;

  -- 3. Check balance
  v_balance := public.get_points_balance(p_profile_id);
  IF v_balance < v_prize.points_cost THEN
    RAISE EXCEPTION 'Insufficient balance';
  END IF;

  -- 4. Idempotency check
  SELECT id INTO v_existing_id
  FROM public.reward_redemptions
  WHERE idempotency_key = p_idempotency_key;
  IF FOUND THEN
    RETURN v_existing_id;
  END IF;

  -- 5. Insert redemption
  INSERT INTO public.reward_redemptions (profile_id, prize_id, company_id, points_spent, status, idempotency_key)
  VALUES (p_profile_id, p_prize_id, p_company_id, v_prize.points_cost, 'pending', p_idempotency_key)
  RETURNING id INTO v_redemption_id;

  -- 6. Insert points transaction
  INSERT INTO public.reward_points (profile_id, company_id, points, transaction_type, description)
  VALUES (p_profile_id, p_company_id, v_prize.points_cost, 'redeemed', 'Resgate — ' || v_prize.name);

  -- 7. Decrement stock
  UPDATE public.reward_prizes
  SET quantity_available = quantity_available - 1
  WHERE id = p_prize_id;

  -- 8. Return
  RETURN v_redemption_id;
END;
$$;

-- Function 3: reject_redemption
CREATE OR REPLACE FUNCTION public.reject_redemption(
  p_redemption_id UUID,
  p_approved_by UUID,
  p_reason TEXT DEFAULT 'Rejeitado pelo gestor'
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_redemption RECORD;
BEGIN
  -- 1. Lock the redemption row
  SELECT * INTO v_redemption
  FROM public.reward_redemptions
  WHERE id = p_redemption_id
  FOR UPDATE;

  -- 2. Validate
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Redemption not found';
  END IF;
  IF v_redemption.status IN ('delivered', 'rejected') THEN
    RAISE EXCEPTION 'Redemption is already in terminal status: %', v_redemption.status;
  END IF;

  -- 3. Update redemption
  UPDATE public.reward_redemptions
  SET status = 'rejected',
      rejection_reason = p_reason,
      approved_by = p_approved_by,
      approved_at = now()
  WHERE id = p_redemption_id;

  -- 4. Refund points
  INSERT INTO public.reward_points (profile_id, company_id, points, transaction_type, description, created_by)
  VALUES (v_redemption.profile_id, v_redemption.company_id, v_redemption.points_spent, 'adjustment', 'Estorno — resgate rejeitado', p_approved_by);

  -- 5. Restore stock
  UPDATE public.reward_prizes
  SET quantity_available = quantity_available + 1
  WHERE id = v_redemption.prize_id;
END;
$$;
