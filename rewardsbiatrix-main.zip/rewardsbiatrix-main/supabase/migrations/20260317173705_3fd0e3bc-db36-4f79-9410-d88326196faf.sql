
-- ============================================================
-- TABLES
-- ============================================================

-- companies
CREATE TABLE public.companies (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL DEFAULT 'Minha Empresa',
  logo_url TEXT,
  biatrix_company_id UUID UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Seed default company
INSERT INTO public.companies (id, name)
VALUES ('00000000-0000-0000-0000-000000000001', 'Minha Empresa');

-- profiles
CREATE TABLE public.profiles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  auth_user_id UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'collaborator' CHECK (role IN ('admin', 'collaborator')),
  avatar_url TEXT,
  company_id UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001' REFERENCES public.companies(id),
  is_active BOOLEAN NOT NULL DEFAULT true,
  biatrix_user_id UUID,
  biatrix_collaborator_id UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_profiles_auth_user_id ON public.profiles(auth_user_id);
CREATE INDEX idx_profiles_company_id ON public.profiles(company_id);
CREATE INDEX idx_profiles_biatrix_user_id ON public.profiles(biatrix_user_id);
CREATE INDEX idx_profiles_biatrix_collaborator_id ON public.profiles(biatrix_collaborator_id);

-- sectors
CREATE TABLE public.sectors (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  company_id UUID NOT NULL REFERENCES public.companies(id),
  biatrix_id UUID,
  name TEXT NOT NULL,
  description TEXT,
  parent_id UUID REFERENCES public.sectors(id),
  level INTEGER NOT NULL DEFAULT 0,
  hierarchy_order INTEGER NOT NULL DEFAULT 0,
  is_advisory BOOLEAN NOT NULL DEFAULT false,
  leader_id UUID REFERENCES public.profiles(id),
  synced_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT uq_sectors_company_biatrix UNIQUE (company_id, biatrix_id)
);

-- Partial unique: only where biatrix_id IS NOT NULL
-- The table-level UNIQUE already covers this but let's add the partial index for correctness
CREATE UNIQUE INDEX idx_sectors_company_biatrix_partial ON public.sectors(company_id, biatrix_id) WHERE biatrix_id IS NOT NULL;

CREATE INDEX idx_sectors_company_id ON public.sectors(company_id);

-- reward_campaigns
CREATE TABLE public.reward_campaigns (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  company_id UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001' REFERENCES public.companies(id),
  name TEXT NOT NULL,
  description TEXT DEFAULT '',
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  points_per_action INTEGER NOT NULL CHECK (points_per_action > 0),
  max_points_per_user INTEGER NOT NULL CHECK (max_points_per_user > 0),
  regulation_url TEXT,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'active', 'completed', 'cancelled')),
  created_by UUID REFERENCES public.profiles(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT chk_campaign_dates CHECK (end_date > start_date)
);

CREATE INDEX idx_reward_campaigns_company_id ON public.reward_campaigns(company_id);
CREATE INDEX idx_reward_campaigns_status ON public.reward_campaigns(status);

-- reward_prizes
CREATE TABLE public.reward_prizes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  company_id UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001' REFERENCES public.companies(id),
  name TEXT NOT NULL,
  description TEXT DEFAULT '',
  points_cost INTEGER NOT NULL CHECK (points_cost > 0),
  image_url TEXT,
  quantity_available INTEGER NOT NULL DEFAULT 0 CHECK (quantity_available >= 0),
  expiration_date DATE,
  delivery_days INTEGER NOT NULL DEFAULT 3 CHECK (delivery_days >= 1),
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_reward_prizes_company_id ON public.reward_prizes(company_id);

-- reward_points
CREATE TABLE public.reward_points (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  company_id UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001' REFERENCES public.companies(id),
  profile_id UUID NOT NULL REFERENCES public.profiles(id),
  campaign_id UUID REFERENCES public.reward_campaigns(id),
  points INTEGER NOT NULL CHECK (points > 0),
  transaction_type TEXT NOT NULL CHECK (transaction_type IN ('earned', 'redeemed', 'expired', 'adjustment')),
  description TEXT DEFAULT '',
  created_by UUID REFERENCES public.profiles(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_reward_points_profile_id ON public.reward_points(profile_id);
CREATE INDEX idx_reward_points_company_id ON public.reward_points(company_id);

-- reward_redemptions
CREATE TABLE public.reward_redemptions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  company_id UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001' REFERENCES public.companies(id),
  profile_id UUID NOT NULL REFERENCES public.profiles(id),
  prize_id UUID NOT NULL REFERENCES public.reward_prizes(id),
  points_spent INTEGER NOT NULL CHECK (points_spent > 0),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'in_approval', 'in_purchase', 'delivered', 'rejected')),
  approved_by UUID REFERENCES public.profiles(id),
  approved_at TIMESTAMPTZ,
  rejection_reason TEXT,
  estimated_delivery_date DATE,
  delivered_at TIMESTAMPTZ,
  idempotency_key UUID NOT NULL DEFAULT gen_random_uuid() UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_reward_redemptions_profile_id ON public.reward_redemptions(profile_id);
CREATE INDEX idx_reward_redemptions_company_id ON public.reward_redemptions(company_id);
CREATE INDEX idx_reward_redemptions_status ON public.reward_redemptions(status);

-- biatrix_sync_logs
CREATE TABLE public.biatrix_sync_logs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  company_id UUID NOT NULL REFERENCES public.companies(id),
  sync_type TEXT NOT NULL,
  status TEXT NOT NULL,
  records_synced INTEGER NOT NULL DEFAULT 0,
  error_message TEXT,
  started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  completed_at TIMESTAMPTZ
);

-- ============================================================
-- TRIGGER: handle_new_user
-- ============================================================

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (auth_user_id, name, email, role)
  VALUES (
    NEW.id,
    COALESCE(
      NEW.raw_user_meta_data->>'name',
      split_part(NEW.email, '@', 1)
    ),
    NEW.email,
    COALESCE(
      NULLIF(NEW.raw_user_meta_data->>'role', ''),
      'collaborator'
    )
  );
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- ============================================================
-- HELPER FUNCTIONS FOR RLS
-- ============================================================

CREATE OR REPLACE FUNCTION public.current_profile_id()
RETURNS UUID
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT id FROM public.profiles WHERE auth_user_id = auth.uid() LIMIT 1;
$$;

CREATE OR REPLACE FUNCTION public.current_profile_role()
RETURNS TEXT
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT role FROM public.profiles WHERE auth_user_id = auth.uid() LIMIT 1;
$$;

-- ============================================================
-- RLS
-- ============================================================

-- Enable RLS on all tables
ALTER TABLE public.companies ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sectors ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reward_campaigns ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reward_prizes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reward_points ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reward_redemptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.biatrix_sync_logs ENABLE ROW LEVEL SECURITY;

-- profiles
CREATE POLICY "profiles_select" ON public.profiles
  FOR SELECT TO authenticated
  USING (id = public.current_profile_id() OR public.current_profile_role() = 'admin');

CREATE POLICY "profiles_update" ON public.profiles
  FOR UPDATE TO authenticated
  USING (id = public.current_profile_id() OR public.current_profile_role() = 'admin');

-- companies
CREATE POLICY "companies_select" ON public.companies
  FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "companies_update" ON public.companies
  FOR UPDATE TO authenticated
  USING (public.current_profile_role() = 'admin');

-- sectors
CREATE POLICY "sectors_select" ON public.sectors
  FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "sectors_insert" ON public.sectors
  FOR INSERT TO authenticated
  WITH CHECK (public.current_profile_role() = 'admin');

CREATE POLICY "sectors_update" ON public.sectors
  FOR UPDATE TO authenticated
  USING (public.current_profile_role() = 'admin');

CREATE POLICY "sectors_delete" ON public.sectors
  FOR DELETE TO authenticated
  USING (public.current_profile_role() = 'admin');

-- reward_campaigns
CREATE POLICY "campaigns_select" ON public.reward_campaigns
  FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "campaigns_insert" ON public.reward_campaigns
  FOR INSERT TO authenticated
  WITH CHECK (public.current_profile_role() = 'admin');

CREATE POLICY "campaigns_update" ON public.reward_campaigns
  FOR UPDATE TO authenticated
  USING (public.current_profile_role() = 'admin');

CREATE POLICY "campaigns_delete" ON public.reward_campaigns
  FOR DELETE TO authenticated
  USING (public.current_profile_role() = 'admin');

-- reward_prizes
CREATE POLICY "prizes_select" ON public.reward_prizes
  FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "prizes_insert" ON public.reward_prizes
  FOR INSERT TO authenticated
  WITH CHECK (public.current_profile_role() = 'admin');

CREATE POLICY "prizes_update" ON public.reward_prizes
  FOR UPDATE TO authenticated
  USING (public.current_profile_role() = 'admin');

CREATE POLICY "prizes_delete" ON public.reward_prizes
  FOR DELETE TO authenticated
  USING (public.current_profile_role() = 'admin');

-- reward_points
CREATE POLICY "points_select" ON public.reward_points
  FOR SELECT TO authenticated
  USING (profile_id = public.current_profile_id() OR public.current_profile_role() = 'admin');

CREATE POLICY "points_insert" ON public.reward_points
  FOR INSERT TO authenticated
  WITH CHECK (public.current_profile_role() = 'admin');

-- reward_redemptions
CREATE POLICY "redemptions_select" ON public.reward_redemptions
  FOR SELECT TO authenticated
  USING (profile_id = public.current_profile_id() OR public.current_profile_role() = 'admin');

CREATE POLICY "redemptions_insert" ON public.reward_redemptions
  FOR INSERT TO authenticated
  WITH CHECK (profile_id = public.current_profile_id());

CREATE POLICY "redemptions_update" ON public.reward_redemptions
  FOR UPDATE TO authenticated
  USING (public.current_profile_role() = 'admin');

-- biatrix_sync_logs
CREATE POLICY "sync_logs_select" ON public.biatrix_sync_logs
  FOR SELECT TO authenticated
  USING (public.current_profile_role() = 'admin');

CREATE POLICY "sync_logs_insert" ON public.biatrix_sync_logs
  FOR INSERT TO authenticated
  WITH CHECK (public.current_profile_role() = 'admin');
