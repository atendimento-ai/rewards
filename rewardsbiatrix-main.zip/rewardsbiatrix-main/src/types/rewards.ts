// Types for the Rewards module

export type CampaignStatus = 'draft' | 'active' | 'completed' | 'cancelled';
export type TransactionType = 'earned' | 'redeemed' | 'expired' | 'adjustment';
export type RedemptionStatus = 'pending' | 'in_approval' | 'in_purchase' | 'delivered' | 'rejected';
export type UserLevel = 'admin' | 'collaborator';

export interface RewardCampaign {
  id: string;
  name: string;
  description: string;
  start_date: string;
  end_date: string;
  points_per_action: number;
  max_points_per_user: number;
  regulation_url?: string;
  status: CampaignStatus;
  created_by: string;
  created_at: string;
}

export interface RewardPoint {
  id: string;
  profile_id: string;
  campaign_id?: string;
  points: number;
  transaction_type: TransactionType;
  description: string;
  created_by?: string;
  created_at: string;
}

export interface RewardPrize {
  id: string;
  name: string;
  description: string;
  points_cost: number;
  image_url?: string;
  quantity_available: number;
  expiration_date?: string;
  delivery_days: number;
  is_active: boolean;
  created_at: string;
}

export interface RewardRedemption {
  id: string;
  profile_id: string;
  profile_name?: string;
  prize_id: string;
  prize_name?: string;
  points_spent: number;
  status: RedemptionStatus;
  approved_by?: string;
  approved_at?: string;
  rejection_reason?: string;
  estimated_delivery_date?: string;
  delivered_at?: string;
  created_at: string;
}

export interface Profile {
  id: string;
  auth_user_id: string;
  name: string;
  email: string;
  role: 'admin' | 'collaborator';
  avatar_url?: string;
  company_id: string;
  is_active: boolean;
  biatrix_user_id?: string;
  biatrix_collaborator_id?: string;
  created_at: string;
}
