import { useState, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Settings as SettingsIcon, Building2, ImageIcon, Trash2, ArrowLeft, RefreshCw, Link2, Loader2 } from "lucide-react";
import { useAppSettings } from "@/contexts/AppSettingsContext";
import { useAuth } from "@/hooks/useAuth";
import { useBiatrixSync } from "@/hooks/useBiatrixSync";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";

export default function Settings() {
  const { settings, updateSettings } = useAppSettings();
  const { profile } = useAuth();
  const { lastSync, isSyncing, triggerSync } = useBiatrixSync();
  const [companyName, setCompanyName] = useState(settings.companyName);
  const [biatrixId, setBiatrixId] = useState("");
  const [savingBiatrixId, setSavingBiatrixId] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  // Load biatrix_company_id on mount
  const [biatrixIdLoaded, setBiatrixIdLoaded] = useState(false);
  if (!biatrixIdLoaded && profile?.company_id) {
    setBiatrixIdLoaded(true);
    supabase
      .from("companies")
      .select("biatrix_company_id")
      .eq("id", profile.company_id)
      .single()
      .then(({ data }) => {
        if (data?.biatrix_company_id) setBiatrixId(data.biatrix_company_id);
      });
  }

  const handleSave = () => {
    updateSettings({ companyName });
    toast.success("Configurações salvas!");
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) {
      toast.error("A imagem deve ter no máximo 2MB.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      updateSettings({ companyLogoUrl: reader.result as string });
      toast.success("Logomarca atualizada!");
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveLogo = () => {
    updateSettings({ companyLogoUrl: null });
    toast.success("Logomarca removida.");
  };

  const handleSaveBiatrixId = async () => {
    if (!profile?.company_id) return;
    setSavingBiatrixId(true);
    const { error } = await supabase
      .from("companies")
      .update({ biatrix_company_id: biatrixId || null })
      .eq("id", profile.company_id);
    setSavingBiatrixId(false);
    if (error) {
      toast.error("Erro ao salvar ID Biatrix.");
    } else {
      toast.success("ID Biatrix salvo!");
    }
  };

  const syncStatusLabel: Record<string, { label: string; className: string }> = {
    started: { label: "Em andamento", className: "border-yellow-700/30 bg-yellow-900/20 text-yellow-400" },
    completed: { label: "Concluída", className: "border-green-700/30 bg-green-900/20 text-green-400" },
    failed: { label: "Falhou", className: "border-red-700/30 bg-red-900/20 text-red-400" },
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border px-4 sm:px-6 py-3 sm:py-4 flex items-center gap-3 sm:gap-4">
        <Button variant="ghost" size="icon" onClick={() => navigate("/")} className="text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div>
          <h1 className="font-display text-lg font-semibold tracking-tight text-foreground flex items-center gap-2">
            <SettingsIcon className="h-5 w-5 text-primary" />
            Configurações
          </h1>
          <p className="text-sm text-muted-foreground">Configurações da empresa e do sistema</p>
        </div>
      </header>

      <div className="max-w-2xl mx-auto p-4 sm:p-6 space-y-6">
        {/* Company Info */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="font-display flex items-center gap-2 text-base">
              <Building2 className="h-5 w-5 text-primary" />
              Dados da Empresa
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="company-name" className="text-sm text-muted-foreground">Nome da Empresa</Label>
              <Input
                id="company-name"
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                className="bg-background border-border"
                placeholder="Nome da sua empresa"
              />
            </div>
            <Button onClick={handleSave} className="bg-primary text-primary-foreground hover:bg-primary/90">
              Salvar Nome
            </Button>
          </CardContent>
        </Card>

        {/* Logo */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="font-display flex items-center gap-2 text-base">
              <ImageIcon className="h-5 w-5 text-primary" />
              Logomarca
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {settings.companyLogoUrl ? (
              <div className="space-y-3">
                <div className="w-40 h-40 border border-border bg-background flex items-center justify-center overflow-hidden p-2">
                  <img src={settings.companyLogoUrl} alt="Logo da empresa" className="max-w-full max-h-full object-contain" />
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => fileInputRef.current?.click()} className="border-border text-foreground hover:bg-secondary">
                    Alterar
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleRemoveLogo} className="border-destructive/30 text-destructive hover:bg-destructive/10">
                    <Trash2 className="h-4 w-4 mr-1" />
                    Remover
                  </Button>
                </div>
              </div>
            ) : (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="w-40 h-40 border-2 border-dashed border-border bg-background flex flex-col items-center justify-center cursor-pointer hover:border-primary/50 transition-colors"
              >
                <ImageIcon className="h-8 w-8 text-muted-foreground mb-2" />
                <span className="text-xs text-muted-foreground">Clique para enviar</span>
                <span className="text-xs text-muted-foreground">PNG, JPG (max 2MB)</span>
              </div>
            )}
            <input
              ref={fileInputRef}
              type="file"
              accept="image/png,image/jpeg,image/webp"
              className="hidden"
              onChange={handleLogoUpload}
            />
          </CardContent>
        </Card>

        {/* Biatrix Integration */}
        {profile?.role === "admin" && (
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="font-display flex items-center gap-2 text-base">
                <Link2 className="h-5 w-5 text-primary" />
                Integração Biatrix
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-xs text-muted-foreground">
                Sincroniza organograma, setores e colaboradores do Biatrix.
              </p>

              <div className="space-y-2">
                <Label htmlFor="biatrix-id" className="text-sm text-muted-foreground">
                  ID da Empresa no Biatrix
                </Label>
                <div className="flex gap-2">
                  <Input
                    id="biatrix-id"
                    value={biatrixId}
                    onChange={(e) => setBiatrixId(e.target.value)}
                    className="bg-background border-border font-mono text-sm"
                    placeholder="UUID da empresa no Biatrix"
                  />
                  <Button
                    variant="outline"
                    onClick={handleSaveBiatrixId}
                    disabled={savingBiatrixId}
                    className="shrink-0"
                  >
                    {savingBiatrixId ? <Loader2 className="h-4 w-4 animate-spin" /> : "Salvar"}
                  </Button>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <Button
                  onClick={triggerSync}
                  disabled={isSyncing || !biatrixId}
                  className="gap-2"
                >
                  {isSyncing ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <RefreshCw className="h-4 w-4" />
                  )}
                  Sincronizar com Biatrix
                </Button>
              </div>

              {lastSync && (
                <div className="border border-border bg-background p-3 space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground">Última sincronização:</span>
                    <Badge variant="outline" className={syncStatusLabel[lastSync.status]?.className ?? ""}>
                      {syncStatusLabel[lastSync.status]?.label ?? lastSync.status}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {new Date(lastSync.started_at).toLocaleString("pt-BR")}
                    {lastSync.records_synced > 0 && ` · ${lastSync.records_synced} registros`}
                  </p>
                  {lastSync.error_message && (
                    <p className="text-xs text-destructive">{lastSync.error_message}</p>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
