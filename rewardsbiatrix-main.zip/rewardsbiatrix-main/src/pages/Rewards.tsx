import { useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Coins, Gift, Trophy, CheckCircle, BarChart3, Settings, Users } from "lucide-react";
import { RewardsProvider, useRewardsContext } from "@/contexts/RewardsContext";
import { OdometerValue } from "@/components/rewards/OdometerValue";
import { VaultScanLine } from "@/components/rewards/VaultScanLine";
import { UserWelcome } from "@/components/rewards/UserWelcome";
import { MobileDrawer } from "@/components/rewards/MobileDrawer";
import { useUserLevel } from "@/hooks/useUserLevel";
import { useAppSettings } from "@/contexts/AppSettingsContext";
import { RewardsPointsTab } from "@/components/rewards/RewardsPointsTab";
import { RewardsCampaignsTab } from "@/components/rewards/RewardsCampaignsTab";
import { RewardsPrizesTab } from "@/components/rewards/RewardsPrizesTab";
import { RewardsApprovalsTab } from "@/components/rewards/RewardsApprovalsTab";
import { RewardsReportsTab } from "@/components/rewards/RewardsReportsTab";
import { CollaboratorsTab } from "@/components/rewards/CollaboratorsTab";
import { Button } from "@/components/ui/button";

function RewardsContent() {
  const [activeTab, setActiveTab] = useState("meus-pontos");
  const { pointsBalance, activeRedemptions, points } = useRewardsContext();
  const { isGestor, userLevel } = useUserLevel();
  const { settings } = useAppSettings();
  const navigate = useNavigate();

  const pendingCount = activeRedemptions.filter(r => r.status === "pending").length;
  const isAdmin = userLevel === "admin";

  const totalDistributed = useMemo(() => {
    if (!isAdmin) return 0;
    return points.filter(p => p.transaction_type === "earned").reduce((a, p) => a + (p.points || 0), 0);
  }, [points, isAdmin]);

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border px-4 sm:px-6 py-3 sm:py-4 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 sm:gap-4 min-w-0">
          <MobileDrawer
            activeTab={activeTab}
            onTabChange={setActiveTab}
            isGestor={isGestor}
            isAdmin={isAdmin}
            pendingCount={pendingCount}
            pointsBalance={pointsBalance}
          />
          {settings.companyLogoUrl && (
            <img src={settings.companyLogoUrl} alt={settings.companyName} className="h-7 w-7 sm:h-8 sm:w-8 object-contain flex-shrink-0" />
          )}
          <div className="min-w-0">
            <h1 className="font-display text-sm sm:text-lg font-semibold tracking-tight text-foreground truncate">
              Programa de Recompensas
            </h1>
            <p className="text-xs sm:text-sm text-muted-foreground truncate">{settings.companyName}</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <UserWelcome />
          {isAdmin && (
            <Button variant="ghost" size="icon" onClick={() => navigate("/configuracoes")} className="hidden lg:flex text-muted-foreground hover:text-foreground">
              <Settings className="h-5 w-5" />
            </Button>
          )}
        </div>
      </header>

      <div className="flex min-h-[calc(100vh-73px)]">
        {/* LEFT — The Vault (30%) */}
        <aside className="hidden lg:flex w-[30%] border-r border-border flex-col items-center justify-center sticky top-0 h-[calc(100vh-73px)] relative">
          <VaultScanLine trigger={isAdmin ? totalDistributed : pointsBalance} />
          <div className="text-center space-y-2 relative z-20">
            <Coins className="h-10 w-10 text-primary mx-auto opacity-70" />
            {isAdmin ? (
              <>
                <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Pontos distribuídos</p>
                <OdometerValue value={totalDistributed} className="text-6xl font-display font-bold text-primary" />
                <p className="text-sm text-muted-foreground">pontos</p>
                <div className="mt-4 pt-4 border-t border-border">
                  <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Resgates pendentes</p>
                  <OdometerValue value={pendingCount} className="text-3xl font-display font-bold text-foreground" />
                </div>
              </>
            ) : (
              <>
                <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Seu saldo</p>
                <OdometerValue value={pointsBalance} className="text-6xl font-display font-bold text-primary" />
                <p className="text-sm text-muted-foreground">pontos</p>
              </>
            )}
          </div>
          <div className="absolute inset-0 pointer-events-none overflow-hidden">
            <div className="absolute left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary to-transparent opacity-20" style={{ top: "50%" }} />
          </div>
        </aside>

        {/* RIGHT — Ledger (70%) */}
        <main className="flex-1 p-4 sm:p-6 lg:w-[70%]">
          <div className="lg:hidden mb-6 border border-border p-4 text-center relative overflow-hidden">
            <VaultScanLine trigger={isAdmin ? totalDistributed : pointsBalance} />
            {isAdmin ? (
              <>
                <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Pontos distribuídos</p>
                <OdometerValue value={totalDistributed} className="text-4xl font-display font-bold text-primary" />
                <p className="text-sm text-muted-foreground">pontos · {pendingCount} resgates pendentes</p>
              </>
            ) : (
              <>
                <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Seu saldo</p>
                <OdometerValue value={pointsBalance} className="text-4xl font-display font-bold text-primary" />
                <p className="text-sm text-muted-foreground">pontos</p>
              </>
            )}
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
            <TabsList className="hidden lg:flex flex-wrap w-full bg-card border border-border gap-0">
              <TabsTrigger value="meus-pontos" className="flex items-center gap-2 font-body data-[state=active]:bg-secondary data-[state=active]:text-foreground">
                <Coins className="h-4 w-4" />
                <span className="hidden sm:inline">Meus Pontos</span>
                <span className="sm:hidden">Pontos</span>
              </TabsTrigger>
              <TabsTrigger value="campanhas" className="flex items-center gap-2 font-body data-[state=active]:bg-secondary data-[state=active]:text-foreground">
                <Trophy className="h-4 w-4" />
                Campanhas
              </TabsTrigger>
              <TabsTrigger value="premios" className="flex items-center gap-2 font-body data-[state=active]:bg-secondary data-[state=active]:text-foreground">
                <Gift className="h-4 w-4" />
                Prêmios
              </TabsTrigger>
              {isGestor && (
                <TabsTrigger value="aprovacoes" className="flex items-center gap-2 relative font-body data-[state=active]:bg-secondary data-[state=active]:text-foreground">
                  <CheckCircle className="h-4 w-4" />
                  Aprovações
                  {pendingCount > 0 && (
                    <Badge className="ml-1 h-5 w-5 p-0 flex items-center justify-center text-xs bg-primary text-primary-foreground border-0">
                      {pendingCount}
                    </Badge>
                  )}
                </TabsTrigger>
              )}
              {isAdmin && (
                <TabsTrigger value="colaboradores" className="flex items-center gap-2 font-body data-[state=active]:bg-secondary data-[state=active]:text-foreground">
                  <Users className="h-4 w-4" />
                  Colaboradores
                </TabsTrigger>
              )}
              {isGestor && (
                <TabsTrigger value="relatorios" className="flex items-center gap-2 font-body data-[state=active]:bg-secondary data-[state=active]:text-foreground">
                  <BarChart3 className="h-4 w-4" />
                  Relatórios
                </TabsTrigger>
              )}
            </TabsList>

            <TabsContent value="meus-pontos"><RewardsPointsTab /></TabsContent>
            <TabsContent value="campanhas"><RewardsCampaignsTab isGestor={isGestor} /></TabsContent>
            <TabsContent value="premios"><RewardsPrizesTab isGestor={isGestor} isAdmin={isAdmin} /></TabsContent>
            {isGestor && <TabsContent value="aprovacoes"><RewardsApprovalsTab /></TabsContent>}
            {isAdmin && <TabsContent value="colaboradores"><CollaboratorsTab /></TabsContent>}
            {isGestor && <TabsContent value="relatorios"><RewardsReportsTab /></TabsContent>}
          </Tabs>
        </main>
      </div>
    </div>
  );
}

export default function Rewards() {
  return (
    <RewardsProvider>
      <RewardsContent />
    </RewardsProvider>
  );
}
